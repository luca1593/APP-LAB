<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en « wp-config.php » et remplir les
 * valeurs.
 *
 * Ce fichier contient les réglages de configuration suivants :
 *
 * Réglages MySQL
 * Préfixe de table
 * Clés secrètes
 * Langue utilisée
 * ABSPATH
 *
 * @link https://fr.wordpress.org/support/article/editing-wp-config-php/.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define( 'DB_NAME', 'applab' );

/** Utilisateur de la base de données MySQL. */
define( 'DB_USER', 'root' );

/** Mot de passe de la base de données MySQL. */
define( 'DB_PASSWORD', '' );

/** Adresse de l’hébergement MySQL. */
define( 'DB_HOST', 'localhost' );

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/**
 * Type de collation de la base de données.
 * N’y touchez que si vous savez ce que vous faites.
 */
define( 'DB_COLLATE', '' );

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clés secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '<{*ilu/K4TIf!Auo&mmd&Qoi:*7i@bz?=9-9;iRTZ   &;.e=t/g6t:RBZd/Xwtm' );
define( 'SECURE_AUTH_KEY',  'aWeyg{Q<^Ma*S-HVOU[R1#,2AhybeAbBbr3j#H7UZo=K`0yrNldIwJhR)**:mkqv' );
define( 'LOGGED_IN_KEY',    'E[DG#a!1s8Td`$tr{6{jMq]KgK4PF2|WM`x{$&C2_?7$rjlV,#+Cn*^X!Q1F{m%$' );
define( 'NONCE_KEY',        '*MylMFT@6}e)R arD=+p,Gs`Ya,oyYt[L4[/XU5rY[<hlcfmN}sC]RmI,Z6y@YA>' );
define( 'AUTH_SALT',        'cba2lQa~7[4ZU3-]bX<]|M|SvC&,sIk>|Jr:JC|8vCfZ43]1CZ-,5T @W#Z0YDD4' );
define( 'SECURE_AUTH_SALT', '4ls_{Ssk>!Pt6z9@av.dM{8BxN$q?5yE!3mIg0W}ZmOK!! hY>:iF3[3_xwb.$3Y' );
define( 'LOGGED_IN_SALT',   'kMvVzd{YL67O}j08}%UVhWX.K:TxDE:/RGMv)`|t*gAbf%wf2dx0l}VYqXjgRJP@' );
define( 'NONCE_SALT',       'ov$akn]W#D7H/hq7}elC}Z:C?yr}zaGX`hxHSgiJC6$8zForVc0h-,+MG{1Ji_or' );
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix = 'wp_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortement recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://fr.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* C’est tout, ne touchez pas à ce qui suit ! Bonne publication. */

/** Chemin absolu vers le dossier de WordPress. */
if ( ! defined( 'ABSPATH' ) )
  define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once( ABSPATH . 'wp-settings.php' );
